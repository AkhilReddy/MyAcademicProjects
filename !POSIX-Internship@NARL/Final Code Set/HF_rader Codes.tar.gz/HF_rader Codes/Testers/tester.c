#include<iostream.h>

int main()
{
int x = 7;
if(x,x++,x==x,0)
{
cout<<"A";
}
else
{
cout<<"B";
}
cout<<x;
return 0;
}
